import { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Tooltip,
  Alert,
  CircularProgress,
  Chip,
  LinearProgress,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Upload as UploadIcon,
  Download as DownloadIcon,
  Refresh as RefreshIcon,
  Business,
} from '@mui/icons-material';
import { DataGrid, GridColDef, GridRowsProp } from '@mui/x-data-grid';
import { useStore } from '../store/useStore';
import api from '../services/api';

interface Branch {
  id: string;
  city: string;
  lat: number;
  lon: number;
  pocket_id: string;
  created_at: string;
  updated_at: string;
}

export default function Branches() {
  const { setError, setSuccess } = useStore();
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingBranch, setEditingBranch] = useState<Branch | null>(null);
  const [formData, setFormData] = useState({
    id: '',
    city: '',
    lat: '',
    lon: '',
  });
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadJobId, setUploadJobId] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);

  useEffect(() => {
    loadBranches();
  }, []);

  const loadBranches = async () => {
    setLoading(true);
    try {
      const data = await api.getBranches({ limit: 1000 });
      console.log('Branches API response:', data);
      // Handle both response formats and field naming conventions
      const branchesData = data.branches || data.data || data;
      const normalizedBranches = Array.isArray(branchesData) 
        ? branchesData.map(branch => ({
            id: branch.id,
            city: branch.city,
            lat: branch.lat,
            lon: branch.lon,
            pocket_id: branch.pocket_id || branch.pocketId,
            created_at: branch.created_at || branch.createdAt,
            updated_at: branch.updated_at || branch.updatedAt,
          }))
        : [];
      setBranches(normalizedBranches);
    } catch (error: any) {
      console.error('Failed to load branches:', error);
      setError(error.message || 'Failed to load branches');
      // Set empty array on error to prevent infinite loading
      setBranches([]);
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = () => {
    setEditingBranch(null);
    setFormData({
      id: '',
      city: '',
      lat: '',
      lon: '',
    });
    setOpenDialog(true);
  };

  const handleEdit = (branch: Branch) => {
    setEditingBranch(branch);
    setFormData({
      id: branch.id,
      city: branch.city,
      lat: branch.lat.toString(),
      lon: branch.lon.toString(),
    });
    setOpenDialog(true);
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this branch?')) {
      return;
    }

    try {
      await api.deleteBranch(id);
      setSuccess('Branch deleted successfully');
      loadBranches();
    } catch (error: any) {
      setError(error.message || 'Failed to delete branch');
    }
  };

  const handleSave = async () => {
    // Validation
    if (!formData.id || !formData.city || !formData.lat || !formData.lon) {
      setError('Please fill in all required fields');
      return;
    }

    const lat = parseFloat(formData.lat);
    const lon = parseFloat(formData.lon);

    if (isNaN(lat) || isNaN(lon)) {
      setError('Invalid coordinates');
      return;
    }

    if (lat < -90 || lat > 90) {
      setError('Latitude must be between -90 and 90');
      return;
    }

    if (lon < -180 || lon > 180) {
      setError('Longitude must be between -180 and 180');
      return;
    }

    const branchData = {
      id: formData.id,
      city: formData.city,
      lat: lat,
      lon: lon,
    };

    try {
      if (editingBranch) {
        await api.updateBranch(editingBranch.id, branchData);
        setSuccess('Branch updated successfully');
      } else {
        await api.createBranch(branchData);
        setSuccess('Branch created successfully');
      }
      setOpenDialog(false);
      loadBranches();
    } catch (error: any) {
      setError(error.message || 'Failed to save branch');
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
        setError('Please select an Excel file (.xlsx or .xls)');
        return;
      }
      // Create a copy of the file to avoid ERR_UPLOAD_FILE_CHANGED
      const blob = file.slice(0, file.size, file.type);
      const newFile = new File([blob], file.name, { type: file.type });
      setSelectedFile(newFile);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setError('Please select a file');
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    
    try {
      console.log('Starting upload for file:', selectedFile.name);
      
      // Start upload - returns immediately with job ID
      const response = await api.uploadBranches(selectedFile);
      console.log('Upload response:', response);
      
      const jobId = response.jobId;
      
      if (!jobId) {
        throw new Error('No job ID returned from server');
      }
      
      setUploadJobId(jobId);
      setSuccess(`Upload started. Job ID: ${jobId}`);

      // Poll for job status
      let pollCount = 0;
      const maxPolls = 120; // 2 minutes max
      
      const pollInterval = setInterval(async () => {
        pollCount++;
        
        if (pollCount > maxPolls) {
          clearInterval(pollInterval);
          setUploading(false);
          setUploadJobId(null);
          setUploadProgress(0);
          setError('Upload timeout - please check job status manually');
          return;
        }
        
        try {
          console.log(`Polling job status (attempt ${pollCount})...`);
          const status = await api.getJobStatus(jobId);
          console.log('Job status:', status);
          
          // Update progress
          const progress = status.progress || 0;
          setUploadProgress(progress);

          if (status.status === 'completed') {
            clearInterval(pollInterval);
            setUploading(false);
            setUploadDialogOpen(false);
            setSelectedFile(null);
            setUploadJobId(null);
            setUploadProgress(0);
            
            // Reset file input
            const fileInput = document.getElementById('file-upload') as HTMLInputElement;
            if (fileInput) fileInput.value = '';
            
            const result = status.result;
            setSuccess(`Successfully uploaded ${result.summary.inserted} branches`);
            loadBranches();
          } else if (status.status === 'failed') {
            clearInterval(pollInterval);
            setUploading(false);
            setUploadJobId(null);
            setUploadProgress(0);
            setError(status.error || 'Upload failed');
          } else if (status.status === 'active') {
            console.log('Job is active, progress:', progress);
          } else {
            console.log('Job status:', status.status);
          }
        } catch (pollError: any) {
          console.error('Poll error:', pollError);
          clearInterval(pollInterval);
          setUploading(false);
          setUploadJobId(null);
          setUploadProgress(0);
          setError(`Failed to check upload status: ${pollError.message}`);
        }
      }, 1000); // Poll every second

    } catch (error: any) {
      console.error('Upload error:', error);
      setUploading(false);
      setUploadJobId(null);
      setUploadProgress(0);
      setError(error.message || 'Failed to start upload');
    }
  };

  const handleExport = async () => {
    try {
      const blob = await api.exportBranches();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `branches_${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      setSuccess('Branches exported successfully');
    } catch (error: any) {
      setError(error.message || 'Failed to export branches');
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      const blob = await api.downloadBranchTemplate();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'branch_upload_template.xlsx';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      setSuccess('Template downloaded successfully');
    } catch (error: any) {
      setError(error.message || 'Failed to download template');
    }
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'Branch ID', width: 120 },
    { field: 'city', headerName: 'City/Name', width: 200, flex: 1 },
    {
      field: 'lat',
      headerName: 'Latitude',
      width: 120,
      valueFormatter: (params) => params.toFixed(6),
    },
    {
      field: 'lon',
      headerName: 'Longitude',
      width: 120,
      valueFormatter: (params) => params.toFixed(6),
    },
    {
      field: 'pocket_id',
      headerName: 'Pocket ID',
      width: 180,
      renderCell: (params) => (
        <Chip
          label={params.value}
          size="small"
          sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}
        />
      ),
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 120,
      sortable: false,
      renderCell: (params) => (
        <Box>
          <Tooltip title="Edit">
            <IconButton
              size="small"
              onClick={() => handleEdit(params.row as Branch)}
              color="primary"
            >
              <EditIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Tooltip title="Delete">
            <IconButton
              size="small"
              onClick={() => handleDelete(params.row.id)}
              color="error"
            >
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ];

  return (
    <Box sx={{ width: '100%', height: '100%', p: 3 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" gutterBottom>
            Branch Management
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Manage branch locations and their Pocket IDs
          </Typography>
        </Box>
        <Box display="flex" gap={1}>
          <Tooltip title="Refresh">
            <IconButton onClick={loadBranches} disabled={loading}>
              <RefreshIcon />
            </IconButton>
          </Tooltip>
          <Button
            variant="outlined"
            startIcon={<DownloadIcon />}
            onClick={handleDownloadTemplate}
          >
            Download Template
          </Button>
          <Button
            variant="outlined"
            startIcon={<UploadIcon />}
            onClick={() => setUploadDialogOpen(true)}
          >
            Upload Excel
          </Button>
          <Button
            variant="outlined"
            startIcon={<DownloadIcon />}
            onClick={handleExport}
            disabled={branches.length === 0}
          >
            Export Excel
          </Button>
          <Button variant="contained" startIcon={<AddIcon />} onClick={handleAdd}>
            Add Branch
          </Button>
        </Box>
      </Box>

      {branches.length === 0 && !loading && (
        <Alert severity="info" sx={{ mb: 2 }}>
          <Typography variant="body2" sx={{ fontWeight: 600, mb: 0.5 }}>
            Getting Started with Branches
          </Typography>
          <Typography variant="body2">
            Branches represent your physical service locations (offices, stores, warehouses). 
            Each branch is automatically assigned a Pocket ID based on its geographic coordinates. 
            Start by adding branches manually or upload an Excel file with multiple branches.
          </Typography>
        </Alert>
      )}

      <Paper sx={{ height: 'calc(100vh - 250px)', width: '100%' }}>
        {!loading && branches.length === 0 ? (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
              p: 4,
            }}
          >
            <Business sx={{ fontSize: 80, color: 'text.secondary', mb: 2 }} />
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No Branches Found
            </Typography>
            <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3, maxWidth: 500 }}>
              Get started by adding your first branch manually or upload multiple branches from an Excel file.
            </Typography>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <Button
                variant="outlined"
                startIcon={<DownloadIcon />}
                onClick={handleDownloadTemplate}
              >
                Download Template
              </Button>
              <Button
                variant="outlined"
                startIcon={<UploadIcon />}
                onClick={() => setUploadDialogOpen(true)}
              >
                Upload Excel
              </Button>
              <Button variant="contained" startIcon={<AddIcon />} onClick={handleAdd}>
                Add First Branch
              </Button>
            </Box>
          </Box>
        ) : (
          <DataGrid
            rows={branches}
            columns={columns}
            loading={loading}
            pageSizeOptions={[10, 25, 50, 100]}
            initialState={{
              pagination: { paginationModel: { pageSize: 25 } },
            }}
            disableRowSelectionOnClick
            sx={{
              '& .MuiDataGrid-cell:focus': {
                outline: 'none',
              },
            }}
          />
        )}
      </Paper>

      {/* Add/Edit Dialog */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editingBranch ? 'Edit Branch' : 'Add New Branch'}</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              label="Branch ID"
              value={formData.id}
              onChange={(e) => setFormData({ ...formData, id: e.target.value })}
              required
              fullWidth
              disabled={!!editingBranch}
              helperText="Unique identifier for the branch (e.g., BR001)"
            />
            <TextField
              label="City/Branch Name"
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
              required
              fullWidth
            />
            <TextField
              label="Latitude"
              type="number"
              value={formData.lat}
              onChange={(e) => setFormData({ ...formData, lat: e.target.value })}
              required
              fullWidth
              inputProps={{ step: 0.000001, min: -90, max: 90 }}
            />
            <TextField
              label="Longitude"
              type="number"
              value={formData.lon}
              onChange={(e) => setFormData({ ...formData, lon: e.target.value })}
              required
              fullWidth
              inputProps={{ step: 0.000001, min: -180, max: 180 }}
            />
            <Alert severity="info">
              Pocket ID will be automatically calculated based on the coordinates
            </Alert>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
          <Button onClick={handleSave} variant="contained">
            {editingBranch ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Upload Dialog */}
      <Dialog
        open={uploadDialogOpen}
        onClose={() => !uploading && setUploadDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Upload Branches from Excel</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            <Alert severity="info" sx={{ mb: 2 }}>
              Excel file should contain columns: <strong>ID</strong>, <strong>City</strong>, <strong>Latitude</strong>, <strong>Longitude</strong>
              <br />
              (Column names are case-insensitive)
            </Alert>
            
            {!uploading && (
              <>
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileSelect}
                  style={{ display: 'none' }}
                  id="file-upload"
                />
                <label htmlFor="file-upload">
                  <Button variant="outlined" component="span" fullWidth>
                    Select Excel File
                  </Button>
                </label>
                {selectedFile && (
                  <Typography variant="body2" sx={{ mt: 2 }}>
                    Selected: {selectedFile.name}
                  </Typography>
                )}
              </>
            )}

            {uploading && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="body2" gutterBottom>
                  Processing upload... {uploadProgress}%
                </Typography>
                <LinearProgress variant="determinate" value={uploadProgress} />
                <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                  {uploadProgress < 10 && 'Parsing Excel file...'}
                  {uploadProgress >= 10 && uploadProgress < 80 && 'Validating data...'}
                  {uploadProgress >= 80 && uploadProgress < 100 && 'Inserting branches...'}
                  {uploadProgress === 100 && 'Finalizing...'}
                </Typography>
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUploadDialogOpen(false)} disabled={uploading}>
            Cancel
          </Button>
          <Button
            onClick={handleUpload}
            variant="contained"
            disabled={!selectedFile || uploading}
            startIcon={uploading ? <CircularProgress size={20} /> : <UploadIcon />}
          >
            {uploading ? 'Uploading...' : 'Upload'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
